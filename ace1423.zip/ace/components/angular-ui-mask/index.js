//https://github.com/angular/angular.js/pull/10732

var angular = require('angular');
var mask = require('./dist/mask');

module.exports = 'ui.mask';
