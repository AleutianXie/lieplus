"use strict";

describe("Multiselect Tests", function() {
	it("Minimal Example", function() {
		browser().navigateTo("index.html");
	});
});
