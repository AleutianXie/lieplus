require('./dist/js/angular-aside');
module.exports = 'ngAside';