require('./slider')
module.exports = 'ui.slider'
